from md2paper.mdloader import GraduationPaper, TranslationPaper
